var active = true;

try {
    chrome.storage.sync.get({
        activate: true
    }, function (items) {
        active = items.activate;
        if (active) {
            main();
        }
        track();
    });
} catch (e) {
    if(active) {
        main();
    }
    track();
} 

function track() {
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-61731142-1', 'auto');
    ga('send', 'pageview');
}

function main() {   
    (function ($) {
        var self = {
            spoilers: {
                1: [
                    "Game of Thrones",
                    "Friends of Thrones"
                ],
                2: [
                    "Tyrion",
                    "Ross"
                ],
                3: [
                    "Arya",
                    "Rachel"
                ],
            },
            handleSpoilers: function(list, time) {
                $.each(list, function(i, val){ 
                    var replace_regex = new RegExp(val[0], 'g');

                    $('body').children().each(function() {
                        $(this).html($(this).html().replace(replace_regex, val[1]));
                    }) 
                })
            }
        };

        $(function () {
            self.handleSpoilers(self.spoilers, 3000);
        });

        $.app = self;

    })(jQuery);
}