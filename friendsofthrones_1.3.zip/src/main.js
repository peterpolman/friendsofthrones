$(document).ready(function(){
    chrome.storage.sync.get('active', function(result){
        if (result.active == true) {
            init();
        }
    });
});

function init() {  
    var self = {
        statics: [['Game of Thrones', 'Friends of Thrones'],['GameofThrones', 'FriendsofThrones'],['Game-of-Thrones', 'Friends-of-Thrones'],],
        names: ['Tyrion','Cersei','Daenerys','Arya','Jon','Sansa','Jorah','Jaime','Sandor','Theon','Samwell','Tywin','Joffrey','Catelyn','Bran','Petyr','Varys','Brienne','Robb','Bronn','Shae','Gendry','Ygritte','Margaery','Stannis','Missandei','Davos','Maester','Melisandre','Roose','Gilly','Tormund','Jeor','Talisa','Eddard','Khal','Ramsay','Olenna','Robert','Oberyn','Daario','Tommen','Viserys','Mance','Ellaria','Hallyne',],
        lastNames: ['Snow','Stark','Targaryen','Lannister','Martell','Bolton','Tyrell','Baratheon','Tully','Greyjoy','FarberArryn','Forrester','Baelish','Tarth','Children of the Forrest','white walker',],
        locations: ['Bravos','Dome','The Wall','Harrenhall','Winterfell','King\'s Landing','Casterly Rock','Castle Black','Volantis','Qarth','Dragonstone','Meereen','Betond the Wall','Riverrun','Storm\'s End','Keep','Highgarden','Pyke','North',],
        friendsNames: ['Chandler','Monica','Phoebe','Rachel','Gunther','Racher','Marcel','Joey','Judy','Ugly Naked Guy','Janice','Mike Hannigan','Carol','Emily','Susan Bunch','Dr. Richard Burke','Estelle Leonard','Charlie Wheeler','Ursula ','Frank Buffay, Jr.','Julie','Tag Jones','Mona','Barry Farber','Mark Robinson','Pete Becker','Alice Knight Buffay','Kathy','Mr. Zelner','Dr. Long','Mr. Heckles','David','Nora Tyler Bing','Mr. Treeger','Joshua Burgin','Janine LaCroix','Elizabeth Stevens','Erica','Paolo','Leonard Green','Sophie','Gary','Jill Green','Amy Green','Stu','Goose',],
        friendsLastNames: ['Geller','Bing','Green','Buffay','Tribbiani','Hannigan','Goralnik',],
        friendsLocations: ['Monica\'s appartment','Central Perk','Chandler and Joey\'s apartment','Phoebe\'s apartment','Ross\' Third apartment','Javu','Allesndro\'s Monica & Chandler\'s apartment','Moondance Diner','Living','Lincon\'s High School','Bloomingdale\'s','The Museum','Becco','Marce\'s Tulsa','Ernie\'s Country House','New York','University','Street',],
        friendsImages: [
            // This needs more image urls with a nice suffix
            'http://www.widewallpapers.net/mod/series/f/friends/1920x1080/Friends-1920x1080-001.jpg',
            'http://theredlist.com/media/database/films/tv-series/comedy-and-romance/1990/friends/002-friends-theredlist.jpg',
            'http://www.wallpaperhi.com/thumbnails/detail/20111129/F.R.I.E.N.D.S..jpg',
            'http://cdn.indiewire.com/dims4/INDIEWIRE/aa7072f/2147483647/crop/574x403%2B35%2B0/resize/680x478/quality/75/?url=http%3A%2F%2Fd1oi7t5trwfj5d.cloudfront.net%2Fe4%2F5f%2F9d3f2fa54c35930c097a50654f7e%2Fhow-i-met-your-mother-series-finale.jpg',
            'http://images2.wikia.nocookie.net/__cb20120304152056/friends/images/thumb/e/e6/Friends-tv-series-wallpapers-1280x1024.jpg/600px-Friends-tv-series-wallpapers-1280x1024.jpg',
            'http://cdn.bluegape.com/wp-content/uploads/2015/03/04163509/download.jpg',
            'https://fbexternal-a.akamaihd.net/safe_image.php?d=AQD35UbemeSq-OdM&w=470&h=246&url=http%3A%2F%2Fs3-static-ak.buzzfed.com%2Fstatic%2F2015-04%2F7%2F13%2Fcampaign_images%2Fwebdr05%2Fhow-well-do-you-know-the-final-episode-of-friends-2-1545-1428426437-10_dblbig.jpg&cfs=1&upscale=1&sx=0&sy=24&sw=625&sh=327',
            'https://fbexternal-a.akamaihd.net/safe_image.php?d=AQDtZ6Dizv-LkDq3&w=470&h=246&url=http%3A%2F%2Fs3-ak.buzzfeed.com%2Fstatic%2F2015-04%2F22%2F12%2Fsocial_promotion%2Fwebdr12%2Ffacebook-social-promotion-23652-1429720339-19.jpg&cfs=1&upscale=1&sx=0&sy=0&sw=1024&sh=536',
            'http://www.radiotimes.com/namedimage/Jessica_Knappett_on_Drifters_series_2__Tinder__bare_bottoms_and_working_with_Ross_from_Friends.jpg?quality=85&mode=crop&width=620&height=374&404=tv&url=/uploads/images/original/59790.jpg',
            'http://10wallpaper.com/view/Gossip_Girl-American_TV_series_Wallpaper_04.html',
            'https://pbs.twimg.com/media/CC3wJBxWEAE22Ct.jpg:large',
            'http://i.ytimg.com/vi/jUjw2pAfesA/hqdefault.jpg',
        ],
        friendsVideos: [
            // We need to expand this array for more random video replacement
            'https://www.youtube.com/embed/CZ9oD85Eirw',
            'https://www.youtube.com/embed/AVFqYMkO1o4',
        ],
        findAndReplace: function(searchText, replacement, searchNode) {
            if (!searchText || typeof replacement === 'undefined') {
                return;
            }
            var regex = typeof searchText === 'string' ?
                        new RegExp(searchText, 'gi') : searchText,
                childNodes = (searchNode || document.body).childNodes,
                cnLength = childNodes.length,
                excludes = 'input';
            while (cnLength--) {
                var currentNode = childNodes[cnLength];
                if (currentNode.nodeType === 1 && (excludes + ',').indexOf(currentNode.nodeName.toLowerCase() + ',') === -1) {
                    arguments.callee(searchText, replacement, currentNode);
                }
                if (currentNode.nodeType !== 3 || !regex.test(currentNode.data) ) {
                    continue;
                }
                var parent = currentNode.parentNode,
                    frag = (function(){
                        var html = currentNode.data.replace(regex, replacement),
                            wrap = document.createElement('div'),
                            frag = document.createDocumentFragment();
                        wrap.innerHTML = html;
                        while (wrap.firstChild) {
                            frag.appendChild(wrap.firstChild);
                        }
                        //update context var to determine of images should be replaced
                        self.context++;
                        return frag;
                    })();
                parent.insertBefore(frag, currentNode);
                parent.removeChild(currentNode);
            }
        },
        handleSpoilers: function(statics,names,lastNames,locations) {
            // Search for statics
            $.each(statics, function(i, val){
                self.findAndReplace(val[0], val[1]); 
            });
            // Search for names
            $.each(names, function(i, val){
                var randInt = Math.floor(Math.random() * self.friendsNames.length);
                self.findAndReplace(val, self.friendsNames[randInt]); 
            });
            // Search for lastNames
            $.each(lastNames, function(i, val){
                var randInt = Math.floor(Math.random() * self.friendsLastNames.length);
                self.findAndReplace(val, self.friendsLastNames[randInt]);
            });
            // Search for locations
            $.each(locations, function(i, val){
                var randInt = Math.floor(Math.random() * self.friendsLocations.length);
                self.findAndReplace(val, self.friendsLocations[randInt]); 
            });

            var timer = setTimeout(function(){
                self.handleSpoilers(self.statics,self.names,self.lastNames,self.locations);
            }, 100);
            
            clearTimeout(timer);
        },
        handleImg: function (item, lstImgs) {
            $(item).error(function () {
                self.handleBrokenImg(item, lstImgs);
            });

            self.setRandomImg(item, lstImgs);
        },
        setRandomImg: function (item, lstImgs) {
            var h = $(item).height();
            var w = $(item).width();
            $(item).css('width', w + 'px').css('height', h + 'px');
            $(item).attr('src', lstImgs[Math.floor(Math.random() * lstImgs.length)]);
        },
        handleBrokenImg: function (item, lstImgs) {

            var brokenImg = $(item).attr('src');
            var index = lstImgs.indexOf(brokenImg);
            if (index > -1) {
                lstImgs.splice(index, 1);
            }
            self.setRandomImg(item, lstImgs);
        },
        handleImages: function(lstImgs){
            $.each($('img'), function (i, item) {
                if ($.inArray($(item).attr('src'), lstImgs) == -1) {
                    var h = $(item).height();
                    var w = $(item).width();

                    if (h > 0 && w > 0) {
                        self.handleImg(item, lstImgs);
                    }
                    else {
                        $(item).load(function () {
                            if ($.inArray($(item).attr('src'), lstImgs) == -1) {
                                self.handleImg(item, lstImgs);
                            }
                        });
                    }
                }
            });
        },
        getYouTubeID: function(url){
            var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
            var match = url.match(regExp);
            if (match&&match[7].length==11){
                return match[7];
            }else{
                return false;
            }
        },
        getYouTubeInfo: function(vidid) {
            var vidInf;
            $.ajax({
                url: "http://gdata.youtube.com/feeds/api/videos/"+vidid+"?v=2&alt=json&orderby=published&prettyprint=true",
                dataType: "json",
                async: false,
                success: function (data) {
                    vidInf = {
                        title: data.entry.title.$t,
                        description: data.entry.media$group.media$description.$t,
                    };
                }
            });
            return vidInf;
        },
        handleVideos: function(lstVids){
            $.each($('iframe'), function (i, item) {
                var ytID = self.getYouTubeID(item.src);
                if(ytID){
                    var n,o;
                    var result;
                    var videoInfo = self.getYouTubeInfo(ytID);
                    var checkVideoInfo = function(data){
                        n = videoInfo.title.search(data);
                        o = videoInfo.description.search(data);

                        if(n != -1 || o != -1){
                            result = true;
                        }
                    }
                    $.each(self.statics, function (i, item) {
                        checkVideoInfo(item[0]);
                    });
                    $.each(self.names, function (i, item) {
                        checkVideoInfo(item);
                    });
                    $.each(self.lastNames, function (i, item) {
                        checkVideoInfo(item);
                    });
                    $.each(self.locations, function (i, item) {
                        checkVideoInfo(item);
                    });

                    if(result){
                        var randInt = Math.floor(Math.random() * lstVids.length);
                        item.setAttribute('src',lstVids[randInt]);
                    }
                }
            });
        }
    };

    self.handleSpoilers(self.statics,self.names,self.lastNames,self.locations);
    self.handleImages(self.friendsImages);
    self.handleVideos(self.friendsVideos);
    
}